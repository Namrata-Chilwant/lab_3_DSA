module LabDSA2 {
}